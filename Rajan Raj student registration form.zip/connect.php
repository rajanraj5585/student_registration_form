<?php
if(!($con = new mysqli("localhost","root","","student_data")));{
    return $con;
    die(mysqli_connect_error());
}
?>