<?php
$name = $_POST['name'];
$age = $_POST['age'];
$mob = $_POST['mob'];

function alertt($msg){
    echo "<script>alert('$msg')</script>";
}

if($name==NULL || $age==NULL || $mob==NULL){
    header("Refresh:0; ./index.html");
}
else{
    echo "Loaded!";
    $con = include_once 'connect.php';
    if(!$con){
        alertt("error connecting to database.");
    }
    else{
        $con->query("INSERT INTO students VALUES('$name',$age,$mob);");
        alertt("Added to database");
        header("Refresh:0; index.html");
    }
    mysqli_close($con);
}
?>