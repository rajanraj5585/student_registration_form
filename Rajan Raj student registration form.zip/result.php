<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results</title>
    <style>
        *{
            font-size:20px
        }
        table{
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<?php 
$con = include_once 'connect.php';
if(!$con){
        alertt("error connecting to database.");
        header("Refresh:0; ./index.html");
}
// $rec = mysqli_query($con,"SELECT * FROM students");
$rec = $con->query("SELECT * FROM students");
?>
<body>
<p>Note: refresh page to get new results.</p>
    <table border=2>
        <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Contact</th>
        </tr>
<?php
while($data = mysqli_fetch_array($rec)){
        echo "<tr>";
            echo "<td>".$data[0]."</td>";
            echo "<td>".$data[1]."</td>";
            echo "<td>".$data[2]."</td>";
        echo "</tr>";
}
?>
    </table>
</body>
</html>